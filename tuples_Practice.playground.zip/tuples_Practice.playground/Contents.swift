import UIKit

var greeting = "Hello, playground"

var httpError = (errorCode : 404, errorMsg : "Page Not Found")
print(httpError)
print(httpError.errorCode , terminator : ": ")
print(httpError.errorMsg)

var name = ("Rajesh","Arigela")
var fname = name.0
var lname = name.1
print(fname,terminator: ",")
print(lname)

var origin = (x:0,y:0)
var point = origin
print(point)

let city = (name:"Tanuku",population:10000)
let (cityName, cityPopulation) = (city.0, city.1)
print(cityName)
print(cityPopulation)

let groceries = ("bread","onions")
print(groceries.0)
print(groceries.1)
print(type(of: groceries))

var fname1 = "Rajesh"
var lname2 = "Arigela"
(fname1,lname2) = (lname2,fname1)
print("First Name is \(fname1) and Last Name is \(lname2)")

var cricketKit = ("HandGloves", "Helmet", ("Bat","Ball"))
print(cricketKit.0)
print(cricketKit.1)
print(cricketKit.2.0)
print(cricketKit.2.1)
