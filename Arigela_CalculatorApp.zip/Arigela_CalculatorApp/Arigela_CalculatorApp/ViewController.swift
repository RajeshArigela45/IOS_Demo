//
//  ViewController.swift
//  Arigela_CalculatorApp
//
//  Created by Rajesh Arigela on 2/5/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var resultOutlet: UILabel!
    
    var value1:String = " "
    var value2:String = " "
    var calculation:Character = " ";
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func buttonAllClear(_ sender: Any) {
        resultOutlet.text=""
        value1 = " "
        value2 = " "
        calculation = " "
    }
    
    @IBAction func buttonClear(_ sender: Any) {
        if(value2 != " "){
             value2=String(value2[value2.startIndex..<value2.index(value2.endIndex,offsetBy: -1)])
             
             resultOutlet.text=value2
             
         }
         
         else if(value1 != " "){
             value1=String(value1[value1.startIndex..<value1.index(value1.endIndex,offsetBy: -1)])
             resultOutlet.text=value1
             
         }
    }
    
    @IBAction func buttonSignChange(_ sender: Any) {
        if(value2 != " "){
                    if(value2.contains(".")){
                        value2 = "\(-Double(value2)!)"
                        resultOutlet.text=value2
                    }
                    else{
                        value2 = "\(-Int(value2)!)"
                        resultOutlet.text=value2
                    }
                    
                }
                else if(value1 != " ") {
                    if(value1.contains(".")){
                        value1 = "\(-Double(value1)!)"
                        resultOutlet.text=value1
                    }
                    else{
                        value1 = "\(-Int(value1)!)"
                        resultOutlet.text=value1
                    }
                }
    }
    
    @IBAction func buttonDivide(_ sender: Any) {
        calculation="/"
    }
    
    @IBAction func buttonSeven(_ sender: Any) {
        if (value1 == " " && calculation == " " ){
                    value1="7"
                    resultOutlet.text="\(value1)"
                }else if(value1 != " " && calculation == " " ){
                    value1=value1+"7"
                    resultOutlet.text="\(value1)"
                }
                else if(value2 == " " && calculation != " "){
                    value2 = "7"
                    resultOutlet.text="\(value2)"
                }
                else if(value2 != " "){
                    value2=value2+"7"
                    resultOutlet.text="\(value2)"
                }
    }
    
    @IBAction func buttonEight(_ sender: Any) {
        if (value1 == " " && calculation == " " ){
                     value1="8"
                     resultOutlet.text="\(value1)"
                 }else if(value1 != " " && calculation == " " ){
                     value1=value1+"8"
                     resultOutlet.text="\(value1)"
                 }
                 else if(value2 == " " && calculation != " "){
                     value2 = "8"
                     resultOutlet.text="\(value2)"
                 }
                 else if(value2 != " "){
                     value2=value2+"8"
                     resultOutlet.text="\(value2)"
                 }
    }
    
    @IBAction func buttonNine(_ sender: Any) {
        if (value1 == " " && calculation == " " ){
                   value1="9"
                   resultOutlet.text="\(value1)"
               }else if(value1 != " " && calculation == " " ){
                   value1=value1+"9"
                   resultOutlet.text="\(value1)"
               }
               else if(value2 == " " && calculation != " "){
                   value2 = "9"
                   resultOutlet.text="\(value2)"
               }
               else if(value2 != " "){
                   value2=value2+"9"
                   resultOutlet.text="\(value2)"
               }
    }
    
    @IBAction func buttonMultiply(_ sender: Any) {
        calculation="*"
    }
    
    @IBAction func buttonFour(_ sender: Any) {
        if (value1 == " " && calculation == " " ){
                     value1="4"
                     resultOutlet.text="\(value1)"
                 }else if(value1 != " " && calculation == " " ){
                     value1=value1+"4"
                     resultOutlet.text="\(value1)"
                 }
                 else if(value2 == " " && calculation != " "){
                     value2 = "4"
                     resultOutlet.text="\(value2)"
                 }
                 else if(value2 != " "){
                     value2=value2+"4"
                     resultOutlet.text="\(value2)"
                 }
    }
    
    @IBAction func buttonFive(_ sender: Any) {
        if (value1 == " " && calculation == " " ){
                    value1="5"
                    resultOutlet.text="\(value1)"
                }else if(value1 != " " && calculation == " " ){
                    value1=value1+"5"
                    resultOutlet.text="\(value1)"
                }
                else if(value2 == " " && calculation != " "){
                    value2 = "5"
                    resultOutlet.text="\(value2)"
                }
                else if(value2 != " "){
                    value2=value2+"5"
                    resultOutlet.text="\(value2)"
                }
    }
    
    @IBAction func buttonSix(_ sender: Any) {
        if (value1 == " " && calculation == " " ){
                    value1="6"
                    resultOutlet.text="\(value1)"
                }else if(value1 != " " && calculation == " " ){
                    value1=value1+"6"
                    resultOutlet.text="\(value1)"
                }
                else if(value2 == " " && calculation != " "){
                    value2 = "6"
                    resultOutlet.text="\(value2)"
                }
                else if(value2 != " "){
                    value2=value2+"6"
                    resultOutlet.text="\(value2)"
                }
    }
    
    @IBAction func buttonMinus(_ sender: Any) {
        calculation="-"
    }
    
    @IBAction func buttonone(_ sender: Any) {
        if (value1 == " " && calculation == " " ){
                    value1="1"
                    resultOutlet.text="\(value1)"
                }else if(value1 != " " && calculation == " " ){
                    value1=value1+"1"
                    resultOutlet.text="\(value1)"
                }
                else if(value2 == " " && calculation != " "){
                    value2 = "1"
                    resultOutlet.text="\(value2)"
                }
                else if(value2 != " "){
                    value2=value2+"1"
                    resultOutlet.text="\(value2)"
                }
    }
    
    @IBAction func buttonTwo(_ sender: Any) {
        if (value1 == " " && calculation == " " ){
                   value1="2"
                   resultOutlet.text="\(value1)"
               }else if(value1 != " " && calculation == " " ){
                   value1=value1+"2"
                   resultOutlet.text="\(value1)"
               }
               else if(value2 == " " && calculation != " "){
                   value2 = "2"
                   resultOutlet.text="\(value2)"
               }
               else if(value2 != " "){
                   value2=value2+"2"
                   resultOutlet.text="\(value2)"
               }
    }
    
    @IBAction func buttonThree(_ sender: Any) {
        if (value1 == " " && calculation == " " ){
                    value1="3"
                    resultOutlet.text="\(value1)"
                }else if(value1 != " " && calculation == " " ){
                    value1=value1+"3"
                    resultOutlet.text="\(value1)"
                }
                else if(value2 == " " && calculation != " "){
                    value2 = "3"
                    resultOutlet.text="\(value2)"
                }
                else if(value2 != " "){
                    value2=value2+"3"
                    resultOutlet.text="\(value2)"
                }
    }

    @IBAction func buttonPlus(_ sender: Any) {
        calculation="+"
    }
    
    @IBAction func buttonZero(_ sender: Any) {
        if (value1 == " " && calculation == " " ){
                   value1="0"
                   resultOutlet.text="\(value1)"
               }else if(value1 != " " && calculation == " " ){
                   value1=value1+"0"
                   resultOutlet.text="\(value1)"
               }
               else if(value2 == " " && calculation != " "){
                   value2 = "0"
                   resultOutlet.text="\(value2)"
               }
               else if(value2 != " "){
                   value2=value2+"0"
                   resultOutlet.text="\(value2)"
               }
    }
    
    @IBAction func buttonDecimal(_ sender: Any) {
        if(value1 == " " && calculation == " "){
                      value1="0."
                      resultOutlet.text="\(value1)"
                  }else if(value1 != " " && calculation == " "){
                      value1=value1+"."
                      resultOutlet.text="\(value1)"
                  }
                  else if(value2 == " " && calculation != " "){
                      value2="0."
                      resultOutlet.text="\(value2)"
                  }else if(value2 != " "){
                      value2=value2+"."
                      resultOutlet.text="\(value2)"
                  }
    }
    
    @IBAction func buttonModular(_ sender: Any) {
        calculation="%"
    }
    
    @IBAction func buttonEquals(_ sender: Any) {
        switch calculation{
                case "+" :
                    if(value1.contains(".")){
                        let val = "\(Double(value1)! + Double(value2)!)"
                        let firstInd=val.firstIndex(of: ".")!.utf16Offset(in: val)
                        let dec = val[val.index(val.startIndex,offsetBy: firstInd+1)]
                        if(dec != "0"){
                            resultOutlet.text = val
                        }
                        else{
                            resultOutlet.text = "\(Int(Double(value1)! + Double(value2)!))"
                        }
                        
                    }
                    else {
                        resultOutlet.text = "\(Int(value1)! + Int(value2)!)"
                    }
                    
                    
                case "-" :
                 
                    if(value1.contains(".")){
                        resultOutlet.text = "\(Double(value1)! - Double(value2)!)"
                    }
                    else {
                        resultOutlet.text = "\(Int(value1)! - Int(value2)!)"
                    }
                
                case "*" :
                    if(value1.contains(".")){
                        resultOutlet.text = "\(Double(value1)! * Double(value2)!)"
                    }
                    else {
                        resultOutlet.text = "\(Int(value1)! * Int(value2)!)"
                    }
                    
                case "/" :
                    if(value1.contains(".")){
                        resultOutlet.text = "\(Double(value1)! / Double(value2)!)"
                    }
                    else {
                        if(value2 == "0"){
                            resultOutlet.text = "Not a number"
                        }
                        else{
                            let calc = "\(Double(value1)! / Double(value2)!)"
                            let calcindex=calc.firstIndex(of: ".")!.utf16Offset(in: calc)
                            let last = calc[calc.index(calc.startIndex,offsetBy: calcindex+1)]
                            if(last != "0"){
                                resultOutlet.text = "\(round(Double(calc)!*100000)/100000)"
                            }
                            else{
                                resultOutlet.text = "\(Int(value1)! / Int(value2)!)"
                            }
                        }
                        
                    }
                    
                case "%" :
                    
                    if(value1.contains(".")){
                        var val = Double(value1)!.truncatingRemainder(dividingBy: Double(value2)!)
                        resultOutlet.text = "\(round(val*10)/10)"
                    }
                    else {
                        resultOutlet.text = "\(Int(value1)! % Int(value2)!)"
                    }
                
                    
                default:
                    print("enter proper sign")
             
                
               }
    }
}
