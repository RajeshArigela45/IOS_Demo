import UIKit

var greeting = "Hello, playground"
print("Rajesh",45,10.18)
var pgmngLang = "OOPS"
var age = 25.5
print("My fav pgmng lang is \(pgmngLang)")
print("My fav pgmng lang is "+pgmngLang)
print("My age is \(age)")
