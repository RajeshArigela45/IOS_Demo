import UIKit

var greeting = "Hello, playground"

var mobileBrand = "Apple"
mobileBrand="Samsung"
print(mobileBrand)

let pi = 3.14
//pi=3.15
print(pi)

var age : Int=25
age=age*2
print(age)

var aweMsg = "This is Superb!"
print(aweMsg)
print("aweMsg")

var c1 = "ios"
var c2 = "java"
print(c1,c2)
print(c1,"-",c2)

print(10,45)
print(10.5, 45.5)
