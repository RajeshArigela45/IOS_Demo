import UIKit

var greeting = "Hello, playground"

print("Hi",10,12.25)

var name="Rajesh Arigela"
print("My name is \(name) 🤟🏻")

var age = 25.5
print("My age is \(age)")

print("you are \(age) years old and in another \(age) years, you will be \(age*2)")

//to print the string in multiple lines
print("""
Hello
World!
""")
//\r used for new line
print ("Hello All, \rWelcome to Swift programming")

//let is used for constants
let wlcmMsg : String = "Hello!"
print(wlcmMsg, "All👋🏻")
print("\n")
print("Welcome to Swift Programming")
print("Spring 2024")
print("***************")
print("Welcome to Swift Programming " , terminator: "-" )
print(" Spring 2024")
print("\n")
print("The list of numbers are ")
print(1,2,3,4,5)
print("The new pattern is ")
print(1,2,3,4,5, separator: "-")
